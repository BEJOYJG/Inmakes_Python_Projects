from django.apps import AppConfig


class DemoApp1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'demo_app_1'
